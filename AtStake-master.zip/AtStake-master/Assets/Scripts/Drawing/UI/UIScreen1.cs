﻿using UnityEngine;
using System.Collections;

public class UIScreen1 : UIScreen {

}
