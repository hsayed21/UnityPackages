Players choose who they want to be the first Decider in the Decider GameState.
