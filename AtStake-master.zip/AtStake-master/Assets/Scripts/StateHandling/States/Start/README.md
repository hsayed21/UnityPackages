The initial GameState - the very first thing a player sees when they load up the game.
