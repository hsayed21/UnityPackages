﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AndroidUtils {
    public const string LOG_TYPE_DEBUG = "d";
    public const string LOG_TYPE_ERROR = "e";
    public const string LOG_TYPE_WARNING = "w";
    public const string LOG_TYPE_INFO = "i";
}
