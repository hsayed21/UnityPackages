The game actually happens in the Round GameState. The Round keeps track of how many times it's begun.
