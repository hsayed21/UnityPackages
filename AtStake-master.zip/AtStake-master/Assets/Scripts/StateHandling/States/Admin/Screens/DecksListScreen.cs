﻿using UnityEngine;
using System.Collections;

public class DecksListScreen : GameScreen {

	public DecksListScreen (GameState state, string name = "Decks List") : base (state, name) {

	}
}
