﻿using UnityEngine;
using System.Collections;

public class BeanValues {

	public static readonly int deciderStart = 500;
	public static readonly int playerStart = 300;
	public static readonly int addTime = 100;
	public static readonly int bonus1 = 100;
	public static readonly int bonus2 = 200;
	public static readonly int roundPot = 300;

}