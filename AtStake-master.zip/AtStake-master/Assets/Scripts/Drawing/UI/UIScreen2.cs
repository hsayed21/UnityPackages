﻿using UnityEngine;
using System.Collections;

public class UIScreen2 : UIScreen {

	void Start () {
		transform.SetXPosition (xRight);
	}
}
