//
//  P31Unity.h
//  P31SharedTools
//
//  Created by Mike Desaro on 9/12/13.
//  Copyright (c) 2013 prime31. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface P31Unity : NSObject

+ (void)unityPause:(NSNumber*)shouldPause;

@end
