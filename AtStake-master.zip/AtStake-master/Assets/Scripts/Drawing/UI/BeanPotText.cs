﻿using UnityEngine;
using System.Collections;

public class BeanPotText : BeanPoolText {}
