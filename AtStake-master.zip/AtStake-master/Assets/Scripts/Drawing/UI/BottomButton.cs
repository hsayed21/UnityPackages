﻿using UnityEngine;
using System.Collections;

public class BottomButton : MiddleButton {

	public override void OnSet () {}
}