﻿using UnityEngine;
using System.Collections;

public class ServerAvailableEvent : GameEvent {

	public ServerAvailableEvent () {}
}
