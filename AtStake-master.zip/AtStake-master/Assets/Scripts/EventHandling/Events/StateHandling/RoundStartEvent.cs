﻿using UnityEngine;
using System.Collections;

public class RoundStartEvent : GameEvent {}
