﻿using UnityEngine;
using System.Collections;

public class RoundEndEvent : GameEvent {}
