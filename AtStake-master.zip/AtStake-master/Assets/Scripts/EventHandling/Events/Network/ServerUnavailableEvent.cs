﻿using UnityEngine;
using System.Collections;

public class ServerUnavailableEvent : GameEvent {

	public ServerUnavailableEvent () {}
}
