﻿using UnityEngine;
using System.Collections;

public class BeanPoolText : MonoBehaviour {

	
}
