﻿using UnityEngine;
using System.Collections;

public class ConnectedToServerEvent : GameEvent {
	
	public ConnectedToServerEvent () {
		
	}
}
