#!/bin/sh
DSTDIR="../../build/Packager/Assets/Plugins/iOS"
cp -r BLEService.h $DSTDIR
cp -r BLEService.mm $DSTDIR
