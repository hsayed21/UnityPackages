﻿using UnityEngine;
using System.Collections;

public class UpdateDrawerEvent : GameEvent {
	
	public UpdateDrawerEvent () {

	}
}
