All of the setup for hosting & joining a game happens in the Multiplayer GameState
