Screen Elements are created in GameScreens and drawn by ScreenDrawer.
