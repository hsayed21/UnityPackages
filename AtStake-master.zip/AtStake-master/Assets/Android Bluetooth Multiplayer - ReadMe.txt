Android Bluetooth Multiplayer v2.0.0
====================================

Thank you for buying, hopefully this plugin will serve you well!

Comprehensive PDF documentation can be found inside the package, or downloaded at this location:
http://cdn.lostpolygon.com/unity-assets/android-bluetooth-multiplayer/files/Android%20Bluetooth%20Multiplayer%20-%20Documentation.pdf
Pre-built Android demo APK:
http://cdn.lostpolygon.com/unity-assets/android-bluetooth-multiplayer/files/AndroidBluetoothMultiplayer_Demo.apk
Forum discussion thread:
http://forum.unity3d.com/threads/188667-Android-Bluetooth-Multiplayer-Released

--
Feel free to contact me anytime via:
E-mail - contact@lostpolygon.com
Skype - serhij.yolkin

--
Lost Polygon � 2015